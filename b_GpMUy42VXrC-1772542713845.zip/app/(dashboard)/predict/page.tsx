import { PredictionForm } from "@/components/prediction-form"

export default function PredictPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">
          Diabetes Prediction
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          AI-powered risk assessment using federated model inference
        </p>
      </div>

      <PredictionForm />
    </div>
  )
}
