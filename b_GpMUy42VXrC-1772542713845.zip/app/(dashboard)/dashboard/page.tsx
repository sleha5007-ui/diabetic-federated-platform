"use client"

import { StatsGrid } from "@/components/stats-grid"
import { PatientsTable } from "@/components/patients-table"
import { AccuracyChart } from "@/components/accuracy-chart"
import { useAuth } from "@/lib/auth-context"

export default function DashboardPage() {
  const { user } = useAuth()

  return (
    <>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground text-balance">
          {user ? `Welcome back, ${user.name}` : "Dashboard"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {user
            ? `${user.hospital} — Overview of your federated learning metrics`
            : "Overview of your federated learning metrics"}
        </p>
      </div>

      <div className="flex flex-col gap-6">
        <StatsGrid />

        <div className="grid gap-6 lg:grid-cols-2">
          <AccuracyChart />
          <PatientsTable />
        </div>
      </div>
    </>
  )
}
