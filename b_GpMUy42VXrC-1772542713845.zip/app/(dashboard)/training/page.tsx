"use client"

import { TrainingSimulation } from "@/components/training-simulation"

export default function TrainingPage() {
  return <TrainingSimulation />
}
